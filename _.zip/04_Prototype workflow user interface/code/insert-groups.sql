/*First we add in the security roles*/
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (301,'G','manager','security-role',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (302,'G','participant','security-role',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (303,'G','administrator','security-role',NULL)

/*Then we add in the organisations*/
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (201,'G','Talent scout','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (202,'G','Legal adviser','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (203,'G','Band member','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (204,'G','Record producer','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (205,'G','Artist development','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (206,'G','Songwriter','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (207,'G','Musician','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (208,'G','Video production','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (209,'G','Artist','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (210,'G','Administrator','organisation',NULL)
INSERT INTO PUBLIC.JBPM_ID_GROUP VALUES (211,'G','Manager','organisation',NULL)

