INSERT INTO PUBLIC.JBPM_ID_USER VALUES (101,'U','powellb','powellb@bland.com','powellb')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (102,'U','rumpoleh','rumpoleh@bland.com','rumpoleh')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (103,'U','memberb','memberb@bland.com','memberb')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (104,'U','dredr','dredr@bland.com','dredr')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (105,'U','harrisr','harrisr@bland.com','harrisr')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (106,'U','lennonj','lennonj@bland.com','lennonj')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (107,'U','hendrixj','hendrixj@bland.com','hendrixj')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (108,'U','welleso','welleso@bland.com','welleso')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (109,'U','monetc','monetc@bland.com','monetc')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (110,'U','admin','admin@bland.com','admin')
INSERT INTO PUBLIC.JBPM_ID_USER VALUES (111,'U','manager','manager@bland.com','manager')


